#!/bin/bash
# Copyright 2018-2020  Daniel Povey
#           2018-2020  Yiming Wang

#对语音识别的理解：
#在基于GMM-HMM的传统语音识别里，比音素（phone）更小的单位是状态（state）。
#一般每个音素由三个状态组成，特殊的是静音（SIL）由五个状态组成。
#这里所说的状态就是指HMM里的隐藏的状态，而每帧数据就是指HMM里的观测值。
#每个状态可以用一个GMM模型表示（这个GMM模型的参数是通过训练得到的）。
#在识别时把每帧数据对应的特征值放进每个状态的GMM里算概率，概率最大的那个就是这帧对应的状态。
#再从状态得到音素（HMM负责），从音素得到词（字典模型负责），从词得到句子（语言模型负责），最终完成识别。

#开始计时,计时起始点 add GLS 2021.9.24
begin_time=`date +%s.%N`


stage=0

. ./cmd.sh
. ./path.sh
. utils/parse_options.sh

set -euo pipefail

########################################################
#实现计时精确到秒。
#starttime=`date +'%Y-%m-%d %H:%M:%S'`
#endtime=`date +'%Y-%m-%d %H:%M:%S'`
#start_seconds=$(date --date="$starttime" +%s);
#end_seconds=$(date --date="$endtime" +%s);
#echo "本次运行时间： "$((end_seconds-start_seconds))"s"
########################################################

########################################################
#实现计时精确到毫秒。 GLS 2021.9.23
function getTiming(){
        start=$1
        end=$2

        start_s=`echo $start| cut -d '.' -f 1`
        start_ns=`echo $start| cut -d '.' -f 2`
        end_s=`echo $end| cut -d '.' -f 1`
        end_ns=`echo $end| cut -d '.' -f 2`

        time_micro=$(( (10#$end_s-10#$start_s)*1000000 + (10#$end_ns/1000 - 10#$start_ns/1000) ))
        time_ms=`expr $time_micro/1000  | bc `

        echo "$time_micro microseconds"
        echo "$time_ms ms"
}

#begin_time=`date +%s.%N`
#sleep 5
#end_time=`date +%s.%N`

#getTiming  $begin_time $end_time
#exit 1;
#实现计时精确到毫秒。 GLS 2021.9.23
#######################################################


if [ $stage -le 0 ]; then  # -le检测左边的数是否小于等于右边的，如果是，则返回 true。
  local/mobvoi_data_download.sh
  echo "$0: Extracted all datasets into data/download/" #提取所有数据集到data/download/
fi
echo "stage0结束。" #stage

if [ $stage -le 1 ]; then
  echo "$0: Preparing datasets..." #准备数据集
  wav_dir=data/download/mobvoi_hotword_dataset
  for folder in train dev eval; do
    mkdir -p data/$folder
    for prefix in p n; do #prefix分别变成p和n，进行for循环
      mkdir -p data/${prefix}_$folder
      json_path=data/download/mobvoi_hotword_dataset_resources/${prefix}_$folder.json
      if [ $folder = "eval" ]; then
        json_path=data/download/mobvoi_hotword_dataset_resources/${prefix}_test.json
      fi
      local/prepare_data.py $wav_dir $json_path data/${prefix}_$folder --non-wake-word "FREETEXT" #更换唤醒词，这里需要修改。 GLS 2021.8.12
    done
    cat data/p_$folder/wav.scp data/n_$folder/wav.scp > data/$folder/wav.scp
    cat data/p_$folder/text data/n_$folder/text > data/$folder/text
    cat data/p_$folder/utt2spk data/n_$folder/utt2spk > data/$folder/utt2spk
    rm -rf data/p_$folder data/n_$folder
  done
  echo "$0: text, utt2spk and wav.scp have been generated in data/{train|dev|eval}." #text, utt2spk and wav.scp在data/{train|dev|eval}中已经生成
fi
echo "stage1结束。" #stage

if [ $stage -le 2 ]; then
  echo "$0: Extracting MFCC..." #提取MFCC
#  for folder in train dev eval; do #暂时注释 GLS 2021.9.7
#    dir=data/$folder
#    utils/fix_data_dir.sh $dir
##    steps/make_mfcc.sh --cmd "$train_cmd" --nj 16 $dir
##    steps/make_mfcc.sh --cmd "$train_cmd" --nj 2 $dir #把16改成2 GLS 2021年 07月 23日 星期五 11:46:57 CST
#    steps/make_mfcc.sh --cmd "$train_cmd" --nj 1 $dir  #2改为1  GLS 2021.9.7
#    steps/compute_cmvn_stats.sh $dir
#    utils/fix_data_dir.sh $dir
#    utils/data/get_utt2dur.sh $dir
#    utils/validate_data_dir.sh $dir #validate验证
#  done

#train数据量变大。dev eval数据两少，就一两条。针对性的处理。 GLS 2021.9.7
#  for folder in dev eval; do #注释 GLS 2021-10-13
  for folder in eval; do #add GLS 2021-10-13
    dir=data/$folder
    utils/fix_data_dir.sh $dir
#    steps/make_mfcc.sh --cmd "$train_cmd" --nj 16 $dir
#    steps/make_mfcc.sh --cmd "$train_cmd" --nj 2 $dir #把16改成2 GLS 2021年 07月 23日 星期五 11:46:57 CST
    echo "给eval steps/make_mfcc.sh --nj 1"
    steps/make_mfcc.sh --cmd "$train_cmd" --nj 1 $dir  #2改为1  GLS 2021.9.7
    steps/compute_cmvn_stats.sh $dir
    utils/fix_data_dir.sh $dir
    utils/data/get_utt2dur.sh $dir
    utils/validate_data_dir.sh $dir #validate验证
  done

  for folder in train ; do
    dir=data/$folder
    utils/fix_data_dir.sh $dir
#    steps/make_mfcc.sh --cmd "$train_cmd" --nj 16 $dir
#    steps/make_mfcc.sh --cmd "$train_cmd" --nj 2 $dir #把16改成2 GLS 2021年 07月 23日 星期五 11:46:57 CST
    echo "给train steps/make_mfcc.sh --nj 2"
#    steps/make_mfcc.sh --cmd "$train_cmd" --nj 3250 $dir  #39300用3500可以 GLS 2021-10-21 #1改为16  2改为1  GLS 2021.9.7
    steps/make_mfcc.sh --cmd "$train_cmd" --nj 2 $dir
    steps/compute_cmvn_stats.sh $dir
    utils/fix_data_dir.sh $dir
    utils/data/get_utt2dur.sh $dir
    utils/validate_data_dir.sh $dir #validate验证
  done

  for folder in dev ; do
    dir=data/$folder
    utils/fix_data_dir.sh $dir
#    steps/make_mfcc.sh --cmd "$train_cmd" --nj 16 $dir
#    steps/make_mfcc.sh --cmd "$train_cmd" --nj 2 $dir #把16改成2 GLS 2021年 07月 23日 星期五 11:46:57 CST
    echo "给dev steps/make_mfcc.sh --nj 1"
#    steps/make_mfcc.sh --cmd "$train_cmd" --nj 750 $dir  #总量39300条，dev用750可以。GLS 2021-10-21 #2改为1  GLS 2021.9.7
    steps/make_mfcc.sh --cmd "$train_cmd" --nj 1 $dir
    steps/compute_cmvn_stats.sh $dir
    utils/fix_data_dir.sh $dir
    utils/data/get_utt2dur.sh $dir
    utils/validate_data_dir.sh $dir #validate验证
  done
fi
echo "stage2结束。"

if [ $stage -le 3 ]; then
  echo "$0: Preparing dictionary and lang..." #准备字典和lang
  local/prepare_dict.sh #更换唤醒词，这里需要修改。 GLS 2021.8.12
  utils/prepare_lang.sh --num-sil-states 1 --num-nonsil-states 4 --sil-prob 0.5 \
    --position-dependent-phones false \
    data/local/dict "<sil>" data/lang/temp data/lang
fi
echo "stage3结束。"

##if [ $stage -le 4 ]; then
##  id_sil=`cat data/lang/words.txt | grep "<sil>" | awk '{print $2}'`
##  id_freetext=`cat data/lang/words.txt | grep "FREETEXT" | awk '{print $2}'`
###  id_word0=`cat data/lang/words.txt | grep "HiXiaowen" | awk '{print $2}'`
##  id_word0=`cat data/lang/words.txt | grep "HiJunlin" | awk '{print $2}'`
###  id_word1=`cat data/lang/words.txt | grep "NihaoWenwen" | awk '{print $2}'`
##  mkdir -p data/lang/lm
##  cat <<EOF > data/lang/lm/fst.txt
##0 1 $id_sil $id_sil
##0 4 $id_sil $id_sil 7.0
##1 4 $id_freetext $id_freetext 0.0
##4 0 $id_sil $id_sil
##1 2 $id_word0 $id_word0 2.3
##2 0 $id_sil $id_sil
##1 3 $id_word1 $id_word1 2.3
##3 0 $id_sil $id_sil
##0
##EOF

##if [ $stage -le 4 ]; then
##  id_sil=`cat data/lang/words.txt | grep "<sil>" | awk '{print $2}'`
##  id_freetext=`cat data/lang/words.txt | grep "FREETEXT" | awk '{print $2}'`
##  id_word0=`cat data/lang/words.txt | grep "HiJunlin" | awk '{print $2}'`
##  mkdir -p data/lang/lm
##  cat <<EOF > data/lang/lm/fst.txt
##0 1 $id_sil $id_sil
##0 4 $id_sil $id_sil 7.0
##1 4 $id_freetext $id_freetext 0.0
##4 0 $id_sil $id_sil
##1 2 $id_word0 $id_word0 2.3
##2 0 $id_sil $id_sil
##0
##EOF

if [ $stage -le 4 ]; then
  id_sil=`cat data/lang/words.txt | grep "<sil>" | awk '{print $2}'`
  id_freetext=`cat data/lang/words.txt | grep "FREETEXT" | awk '{print $2}'`
  id_word0=`cat data/lang/words.txt | grep "HiXiaowen" | awk '{print $2}'`
  mkdir -p data/lang/lm
  cat <<EOF > data/lang/lm/fst.txt
0 1 $id_sil $id_sil
0 4 $id_sil $id_sil 7.0
1 4 $id_freetext $id_freetext 0.0
4 0 $id_sil $id_sil
1 2 $id_word0 $id_word0 2.3
2 0 $id_sil $id_sil
0
EOF

#set +e： 执行的时候如果出现了返回值为非零将会继续执行下面的脚本
#set -e ： 执行的时候如果出现了返回值为非零，整个脚本 就会立即退出
#  set -e 命令用法总结如下：
#  1. 当命令的返回值为非零状态时，则立即退出脚本的执行。
#  2. 作用范围只限于脚本执行的当前进行，不作用于其创建的子进程（https://blog.csdn.net/fc34235/article/details/76598448 ）。
#  3. 另外，当想根据命令执行的返回值，输出对应的log时，最好不要采用set -e选项，而是通过配合exit 命令来达到输出log并退出执行的目的
  fstcompile data/lang/lm/fst.txt data/lang/G.fst #fstcompile先将文本 fst 编译为 二进制文件
  set +e
  fstisstochastic data/lang/G.fst #fstisstochastic检查FST是否随机，如果是，则成功退出。打印出最大错误(以日志为单位)。
  set -e
  utils/validate_lang.pl data/lang

fi
echo "stage4结束。"


if [ $stage -le 5 ]; then
  echo "$0: subsegmenting for the training data..." #对训练数据进行分段
  srcdir=data/train
  utils/data/convert_data_dir_to_whole.sh $srcdir ${srcdir}_whole

  utils/data/get_segments_for_data.sh $srcdir > ${srcdir}_whole/segments
  utils/filter_scp.pl <(awk '{if ($2 == "FREETEXT") print $1}' ${srcdir}_whole/text) \
    ${srcdir}_whole/segments >${srcdir}_whole/neg_segments
  utils/filter_scp.pl --exclude ${srcdir}_whole/neg_segments ${srcdir}_whole/segments \
    >${srcdir}_whole/pos_segments
  utils/filter_scp.pl ${srcdir}_whole/pos_segments ${srcdir}_whole/utt2dur >${srcdir}_whole/pos_utt2dur
  local/get_random_subsegments.py --overlap-duration=0.3 --max-remaining-duration=0.3 \
    ${srcdir}_whole/neg_segments ${srcdir}_whole/pos_utt2dur | \
    cat ${srcdir}_whole/pos_segments - | sort >${srcdir}_whole/sub_segments
  utils/data/subsegment_data_dir.sh ${srcdir}_whole \
    ${srcdir}_whole/sub_segments data/train_segmented
  awk '{print $1,$2}' ${srcdir}_whole/sub_segments | \
    utils/apply_map.pl -f 2 ${srcdir}_whole/text >data/train_segmented/text
#  utils/data/extract_wav_segments_data_dir.sh --nj 50 --cmd "$train_cmd" \
  #50改成16 GLS 2021.7.25
#  utils/data/extract_wav_segments_data_dir.sh --nj 16 --cmd "$train_cmd" \
#1 GLS 2021年 08月 09日 星期一 14:32:32 CST
#  utils/data/extract_wav_segments_data_dir.sh --nj 2 --cmd "$train_cmd" \ #注释GLS 2021.9.7
#  utils/data/extract_wav_segments_data_dir.sh --nj 16 --cmd "$train_cmd" \
#共39300条的时候，暂时用4000 GLS 2021-10-21
#  utils/data/extract_wav_segments_data_dir.sh --nj 4000 --cmd "$train_cmd" \
  utils/data/extract_wav_segments_data_dir.sh --nj 16 --cmd "$train_cmd" \
    data/train_segmented data/train_shorter
  steps/compute_cmvn_stats.sh data/train_shorter
  utils/fix_data_dir.sh data/train_shorter
  utils/validate_data_dir.sh data/train_shorter
fi
echo "stage5结束。"



# In this section, we augment the training data with reverberation,
# noise, music, and babble, and combined it with the clean data.
#在本节中，我们用混响、噪声、音乐和babble来增强训练数据，并将其与干净的数据相结合。
if [ $stage -le 6 ]; then
  utils/data/get_utt2dur.sh data/train_shorter
  cp data/train/utt2dur data/train/reco2dur
  # Download the package that includes the real RIRs, simulated RIRs, isotropic noises and point-source noises
  #下载软件包，其中包括真实的RIRs，模拟的RIRs，各向同性噪声和点源噪声
  #-f file 	检测文件是否是普通文件（既不是目录，也不是设备文件），如果是，则返回 true。
  #-d file 	检测文件是否是目录，如果是，则返回 true。
  [ ! -f rirs_noises.zip ] && wget --no-check-certificate http://www.openslr.org/resources/28/rirs_noises.zip
  [ ! -d "RIRS_NOISES" ] && unzip rirs_noises.zip

  # Make a version with reverberated speech
  #制作一个带有回响的版本
#  此处单小括号 ()作用：
#     命令组。括号中的命令将会新开一个子shell顺序执行，所以括号中的变量不能够被脚本余下的部分使用。
#     括号中多个命令之间用分号隔开，最后一个命令可以没有分号，各命令和括号之间不必有空格。  https://www.cnblogs.com/qlqwjy/p/8684630.html
  rvb_opts=()
  rvb_opts+=(--rir-set-parameters "0.5, RIRS_NOISES/simulated_rirs/smallroom/rir_list")
  rvb_opts+=(--rir-set-parameters "0.5, RIRS_NOISES/simulated_rirs/mediumroom/rir_list")

  # Make a reverberated version of the SWBD+SRE list.  Note that we don't add any
  # additive noise here.
  #制作一个混响版本的SWBD+SRE列表。注意，我们在这里没有添加任何附加的噪声。
  steps/data/reverberate_data_dir.py \
    "${rvb_opts[@]}" \
    --speech-rvb-probability 1 \
    --prefix "rev" \
    --pointsource-noise-addition-probability 0 \
    --isotropic-noise-addition-probability 0 \
    --num-replications 1 \
    --source-sampling-rate 16000 \
    data/train_shorter data/train_shorter_reverb
  cat data/train_shorter/utt2dur | awk -v name=rev1 '{print name"-"$0}' >data/train_shorter_reverb/utt2dur

  # Prepare the MUSAN corpus, which consists of music, speech, and noise
  # suitable for augmentation.
  #编写MUSAN语料库，语料库由音乐、语音和适合增强的噪声组成。
  #  steps/data/make_musan.sh /export/corpora/JHU/musan data  #注释 GLS 2021年 07月 25日 星期日 16:31:31 CST
  steps/data/make_musan.sh musan data                         #/export/corpora/JHU/musan修改为musan GLS 2021年 07月 25日 星期日 16:31:31 CST


  # Get the duration of the MUSAN recordings.  This will be used by the
  # script augment_data_dir.py.
  #获取MUSAN记录的持续时间。这将由augment_data_dir.py脚本使用。
  for name in speech noise music; do
    utils/data/get_utt2dur.sh data/musan_${name}
    cp data/musan_${name}/utt2dur data/musan_${name}/reco2dur
  done

  # Augment with musan_noise #Augment增加
  export LC_ALL=en_US.UTF-8
  steps/data/augment_data_dir.py --utt-prefix "noise" --modify-spk-id true --fg-interval 1 --fg-snrs "15:10:5:0" --fg-noise-dir "data/musan_noise" data/train_shorter data/train_shorter_noise
  # Augment with musan_music
  steps/data/augment_data_dir.py --utt-prefix "music" --modify-spk-id true --bg-snrs "15:10:8:5" --num-bg-noises "1" --bg-noise-dir "data/musan_music" data/train_shorter data/train_shorter_music
  # Augment with musan_speech
  steps/data/augment_data_dir.py --utt-prefix "babble" --modify-spk-id true --bg-snrs "20:17:15:13" --num-bg-noises "3:4:5:6:7" --bg-noise-dir "data/musan_speech" data/train_shorter data/train_shorter_babble
  export LC_ALL=C
fi
echo "stage6结束。"

if [ $stage -le 7 ]; then
  # Now make MFCC features #现在让MFCC功能
  for name in reverb noise music babble; do
  #把16改成2 GLS 2021年 07月 23日 星期五 11:46:57 CST
#    steps/make_mfcc.sh --nj 16 --cmd "$train_cmd" \
#    steps/make_mfcc.sh --nj 2 --cmd "$train_cmd" \
#39300条，用4000跑了近3小时，第7阶段没跑完，我中途终止了。 GLS 2021-10-22
#    steps/make_mfcc.sh --nj 4000 --cmd "$train_cmd" \
    steps/make_mfcc.sh --nj 2 --cmd "$train_cmd" \
      data/train_shorter_${name} || exit 1;
    steps/compute_cmvn_stats.sh data/train_shorter_${name}
    utils/fix_data_dir.sh data/train_shorter_${name}
    utils/validate_data_dir.sh data/train_shorter_${name}
  done
fi

echo "stage7结束。"

# monophone training #单音训练
if [ $stage -le 8 ]; then
#  steps/train_mono.sh --nj 50 --cmd "$train_cmd" \
  #50改成16 GLS 2021.7.25
#  steps/train_mono.sh --nj 16 --cmd "$train_cmd" \
#1 GLS 2021年 08月 09日 星期一 14:32:32 CST
#  steps/train_mono.sh --nj 2 --cmd "$train_cmd" \  #注释 GLS 2021.9.7
#  steps/train_mono.sh --nj 16 --cmd "$train_cmd" \
#  steps/train_mono.sh --nj 100 --cmd "$train_cmd" \
  steps/train_mono.sh --nj 16 --cmd "$train_cmd" \
    data/train_shorter data/lang exp/mono
  (
    utils/mkgraph.sh data/lang \
      exp/mono exp/mono/graph
  )&

#  steps/align_si.sh --nj 50 --cmd "$train_cmd" \
  #50改成16 GLS 2021.7.25
#  steps/align_si.sh --nj 16 --cmd "$train_cmd" \
#1 GLS 2021年 08月 09日 星期一 14:32:32 CST
#  steps/align_si.sh --nj 2 --cmd "$train_cmd" \  #注释 GLS 2021.9.7
#  steps/align_si.sh --nj 16 --cmd "$train_cmd" \
#  steps/align_si.sh --nj 100 --cmd "$train_cmd" \
  steps/align_si.sh --nj 16 --cmd "$train_cmd" \
    data/train_shorter data/lang exp/mono exp/mono_ali_train_shorter
fi
echo "stage8结束。"

if [ $stage -le 9 ]; then
  echo "$0: preparing for low-resolution speed-perturbed data (for alignment)" #准备低分辨率速度扰动数据(用于对齐)
  utils/data/perturb_data_dir_speed_3way.sh data/train_shorter data/train_shorter_sp
#  steps/make_mfcc.sh --cmd "$train_cmd" --nj 30 data/train_shorter_sp || exit 1;
#1 GLS 2021年 08月 09日 星期一 14:32:32 CST
#  steps/make_mfcc.sh --cmd "$train_cmd" --nj 1 data/train_shorter_sp || exit 1;  #注释 GLS 2021.9.7
#  steps/make_mfcc.sh --cmd "$train_cmd" --nj 30 data/train_shorter_sp || exit 1;
#  steps/make_mfcc.sh --cmd "$train_cmd" --nj 100 data/train_shorter_sp || exit 1;
  steps/make_mfcc.sh --cmd "$train_cmd" --nj 1 data/train_shorter_sp || exit 1;
  steps/compute_cmvn_stats.sh data/train_shorter_sp || exit 1;
  utils/fix_data_dir.sh data/train_shorter_sp
fi
echo "stage9结束。"

if [ $stage -le 10 ]; then
  echo "$0: aligning with the perturbed low-resolution data" #与受干扰的低分辨率数据对齐
#  steps/align_fmllr.sh --nj 50 --cmd "$train_cmd" \
  #50 改成16 GLS 2021.7.25
#  steps/align_fmllr.sh --nj 16 --cmd "$train_cmd" \
#1 GLS 2021年 08月 09日 星期一 14:32:32 CST
#  steps/align_fmllr.sh --nj 2 --cmd "$train_cmd" \ #注释 GLS 2021.9.7
#  steps/align_fmllr.sh --nj 16 --cmd "$train_cmd" \
#  steps/align_fmllr.sh --nj 100 --cmd "$train_cmd" \
  steps/align_fmllr.sh --nj 16 --cmd "$train_cmd" \
    data/train_shorter_sp data/lang exp/mono exp/mono_ali_train_shorter_sp || exit 1
fi
echo "stage10结束。"

if [ $stage -le 11 ]; then
  echo "$0: creating high-resolution MFCC features" #创建高分辨率MFCC功能
  mfccdir=data/train_shorter_sp_hires/data
  if [[ $(hostname -f) == *.clsp.jhu.edu ]] && [ ! -d $mfccdir/storage ]; then
    utils/create_split_dir.pl /export/b0{5,6,7,8}/$USER/kaldi-data/egs/mobvoi-$(dte +'%m_%d_%H_%M')/v1/$mfccdir/storage $mfccdir/storage
  fi

  for datadir in train_shorter_sp dev eval; do
    utils/copy_data_dir.sh data/$datadir data/${datadir}_hires
  done

  # do volume-perturbation on the training data prior to extracting hires
  # features; this helps make trained nnets more invariant to test data volume.
#  在提取雇佣特征之前对训练数据进行体积扰动;这有助于使训练有素的nnets在测试数据量时更加不变。
  utils/data/perturb_data_dir_volume.sh data/train_shorter_sp_hires || exit 1;


#注释 GLS 2021-10-14
#  for datadir in train_shorter_sp dev eval; do
##    steps/make_mfcc.sh --nj 50 --mfcc-config conf/mfcc_hires.conf \
#    #50改成16 GLS 2021.7.25
##    steps/make_mfcc.sh --nj 16 --mfcc-config conf/mfcc_hires.conf \
##1 GLS 2021年 08月 09日 星期一 14:32:32 CST
##    steps/make_mfcc.sh --nj 2 --mfcc-config conf/mfcc_hires.conf \  #注释 GLS 2021.9.7
##    steps/make_mfcc.sh --nj 16 --mfcc-config conf/mfcc_hires.conf \
#    #在p_dev.json和p_test.json,n_dev.json,n_test.json只放1条语音数据时，--nj取1。 2021年 09月 07日 星期二 13:12:04 CST
##    steps/make_mfcc.sh --nj 1 --mfcc-config conf/mfcc_hires.conf \
#    steps/make_mfcc.sh --nj 1 --mfcc-config conf/mfcc_hires.conf \
#      --cmd "$train_cmd" data/${datadir}_hires || exit 1;
#    steps/compute_cmvn_stats.sh data/${datadir}_hires || exit 1;
#    utils/fix_data_dir.sh data/${datadir}_hires || exit 1;
#  done
#把eval和train_shorter_sp dev 分开处理。因为eval里只放了1条数据。 GLS 2021-10-14
    for datadir in train_shorter_sp dev ; do
  #    steps/make_mfcc.sh --nj 50 --mfcc-config conf/mfcc_hires.conf \
      #50改成16 GLS 2021.7.25
  #    steps/make_mfcc.sh --nj 16 --mfcc-config conf/mfcc_hires.conf \
  #1 GLS 2021年 08月 09日 星期一 14:32:32 CST
  #    steps/make_mfcc.sh --nj 2 --mfcc-config conf/mfcc_hires.conf \  #注释 GLS 2021.9.7
  #    steps/make_mfcc.sh --nj 16 --mfcc-config conf/mfcc_hires.conf \
      #在p_dev.json和p_test.json,n_dev.json,n_test.json只放1条语音数据时，--nj取1。 2021年 09月 07日 星期二 13:12:04 CST
  #    steps/make_mfcc.sh --nj 1 --mfcc-config conf/mfcc_hires.conf \
#      steps/make_mfcc.sh --nj 100 --mfcc-config conf/mfcc_hires.conf \
      steps/make_mfcc.sh --nj 1 --mfcc-config conf/mfcc_hires.conf \
        --cmd "$train_cmd" data/${datadir}_hires || exit 1;
      steps/compute_cmvn_stats.sh data/${datadir}_hires || exit 1;
      utils/fix_data_dir.sh data/${datadir}_hires || exit 1;
    done
    for datadir in eval ; do
  #    steps/make_mfcc.sh --nj 50 --mfcc-config conf/mfcc_hires.conf \
      #50改成16 GLS 2021.7.25
  #    steps/make_mfcc.sh --nj 16 --mfcc-config conf/mfcc_hires.conf \
  #1 GLS 2021年 08月 09日 星期一 14:32:32 CST
  #    steps/make_mfcc.sh --nj 2 --mfcc-config conf/mfcc_hires.conf \  #注释 GLS 2021.9.7
  #    steps/make_mfcc.sh --nj 16 --mfcc-config conf/mfcc_hires.conf \
      #在p_dev.json和p_test.json,n_dev.json,n_test.json只放1条语音数据时，--nj取1。 2021年 09月 07日 星期二 13:12:04 CST
  #    steps/make_mfcc.sh --nj 1 --mfcc-config conf/mfcc_hires.conf \
      steps/make_mfcc.sh --nj 1 --mfcc-config conf/mfcc_hires.conf \
        --cmd "$train_cmd" data/${datadir}_hires || exit 1;
      steps/compute_cmvn_stats.sh data/${datadir}_hires || exit 1;
      utils/fix_data_dir.sh data/${datadir}_hires || exit 1;
    done
fi
echo "stage11结束。"

combined_train_set=train_shorter_sp_combined
aug_affix="reverb noise music babble" #混响，噪音，音乐，嘈杂声
if [ $stage -le 12 ]; then
  for name in $aug_affix; do
    echo "$0: creating high-resolution MFCC features for train_shorter_${name}" #为train_shorter_${name}创建高分辨率MFCC特性
    mfccdir=data/train_shorter_${name}_hires/data
    if [[ $(hostname -f) == *.clsp.jhu.edu ]] && [ ! -d $mfccdir/storage ]; then
      utils/create_split_dir.pl /export/b0{5,6,7,8}/$USER/kaldi-data/egs/mobvoi-$(date +'%m_%d_%H_%M')/v1/$mfccdir/storage $mfccdir/storage
    fi
    utils/copy_data_dir.sh data/train_shorter_${name} data/train_shorter_${name}_hires
#    steps/make_mfcc.sh --nj 50 --mfcc-config conf/mfcc_hires.conf \
    #50改成16 GLS 2021.7.25
#    steps/make_mfcc.sh --nj 16 --mfcc-config conf/mfcc_hires.conf \
#1 GLS 2021年 08月 09日 星期一 14:32:32 CST
#    steps/make_mfcc.sh --nj 2 --mfcc-config conf/mfcc_hires.conf \ #注释 GLS 2021.9.7
#    steps/make_mfcc.sh --nj 16 --mfcc-config conf/mfcc_hires.conf \
#    steps/make_mfcc.sh --nj 2 --mfcc-config conf/mfcc_hires.conf \
#    steps/make_mfcc.sh --nj 100 --mfcc-config conf/mfcc_hires.conf \
    steps/make_mfcc.sh --nj 2 --mfcc-config conf/mfcc_hires.conf \
      --cmd "$train_cmd" data/train_shorter_${name}_hires || exit 1;
    steps/compute_cmvn_stats.sh data/train_shorter_${name}_hires || exit 1;
    utils/fix_data_dir.sh data/train_shorter_${name}_hires || exit 1;
  done
  eval utils/combine_data.sh data/${combined_train_set}_hires data/train_shorter_sp_hires \
    data/train_shorter_{$(echo $aug_affix | sed 's/ /,/g')}_hires
fi
echo "stage12结束。"

if [ $stage -le 13 ]; then
#run_tdnn.sh是run.sh脚本中的最后一步，也是最重要的一步，其训练一个chain模型，与一般的dnn-hmm模型不同，它不需要事先训练一个交叉熵准则的DNN模型，
#而是直接使用对HMM-HMM模型的对齐结果作为输入。训练chain模型需要安装CUDA使用gpu，具体安装步骤上网查吧。
#更换唤醒词，这里需要修改。 GLS 2021.8.12
  local/chain/run_tdnn.sh --train-set train_shorter --combined-train-set ${combined_train_set}
fi

#################################################
#结束计时,计时终点 add GLS 2021.9.24
end_time=`date +%s.%N`
getTiming  $begin_time $end_time
exit 1




##########-------------------------------------------------------------------------#
##################################################################
##尝试只更换test里面的语音。  GLS 2021.9.8


##简化版本一
#if [ $stage -le 0 ]; then  # -le检测左边的数是否小于等于右边的，如果是，则返回 true。
#  local/mobvoi_data_download.sh
#  echo "$0: Extracted all datasets into data/download/" #提取所有数据集到data/download/
#fi
#echo "stage0结束。" #stage

#if [ $stage -le 1 ]; then
#  echo "$0: Preparing datasets..." #准备数据集
#  wav_dir=data/download/mobvoi_hotword_dataset
#  for folder in eval; do
#    mkdir -p data/$folder
#    for prefix in p n; do #prefix分别变成p和n，进行for循环。即n_test.json,p_test.json等
#      mkdir -p data/${prefix}_$folder
#      json_path=data/download/mobvoi_hotword_dataset_resources/${prefix}_$folder.json
#      if [ $folder = "eval" ]; then
#        json_path=data/download/mobvoi_hotword_dataset_resources/${prefix}_test.json
#      fi
#      local/prepare_data.py $wav_dir $json_path data/${prefix}_$folder --non-wake-word "FREETEXT" #更换唤醒词，这里需要修改。 GLS 2021.8.12
#    done
#    cat data/p_$folder/wav.scp data/n_$folder/wav.scp > data/$folder/wav.scp
#    cat data/p_$folder/text data/n_$folder/text > data/$folder/text
#    cat data/p_$folder/utt2spk data/n_$folder/utt2spk > data/$folder/utt2spk
#    rm -rf data/p_$folder data/n_$folder
#  done
#  echo "$0: text, utt2spk and wav.scp have been generated in data/{train|dev|eval}." #text, utt2spk and wav.scp在data/{train|dev|eval}中已经生成
#fi
#echo "stage1结束。" #stage

#if [ $stage -le 2 ]; then
#  echo "$0: Extracting MFCC..." #提取MFCC
##train数据量变大。dev eval数据两少，就一两条。针对性的处理。 GLS 2021.9.7
#  for folder in eval; do
#    dir=data/$folder
#    utils/fix_data_dir.sh $dir
##    steps/make_mfcc.sh --cmd "$train_cmd" --nj 16 $dir
##    steps/make_mfcc.sh --cmd "$train_cmd" --nj 2 $dir #把16改成2 GLS 2021年 07月 23日 星期五 11:46:57 CST
#    steps/make_mfcc.sh --cmd "$train_cmd" --nj 1 $dir  #2改为1  GLS 2021.9.7
#    steps/compute_cmvn_stats.sh $dir
#    utils/fix_data_dir.sh $dir
#    utils/data/get_utt2dur.sh $dir
#    utils/validate_data_dir.sh $dir #validate验证
#  done
#fi
#echo "stage2结束。"


#if [ $stage -le 11 ]; then
#  echo "$0: creating high-resolution MFCC features" #创建高分辨率MFCC功能
##  mfccdir=data/train_shorter_sp_hires/data
##  if [[ $(hostname -f) == *.clsp.jhu.edu ]] && [ ! -d $mfccdir/storage ]; then
##    utils/create_split_dir.pl /export/b0{5,6,7,8}/$USER/kaldi-data/egs/mobvoi-$(dte +'%m_%d_%H_%M')/v1/$mfccdir/storage $mfccdir/storage
##  fi

#  for datadir in eval; do
#    utils/copy_data_dir.sh data/$datadir data/${datadir}_hires
#  done

#  # do volume-perturbation on the training data prior to extracting hires
#  # features; this helps make trained nnets more invariant to test data volume.
##  在提取雇佣特征之前对训练数据进行体积扰动;这有助于使训练有素的nnets在测试数据量时更加不变。
##  utils/data/perturb_data_dir_volume.sh data/train_shorter_sp_hires || exit 1;

#  for datadir in eval; do
##    steps/make_mfcc.sh --nj 50 --mfcc-config conf/mfcc_hires.conf \
#    #50改成16 GLS 2021.7.25
##    steps/make_mfcc.sh --nj 16 --mfcc-config conf/mfcc_hires.conf \
##1 GLS 2021年 08月 09日 星期一 14:32:32 CST
##    steps/make_mfcc.sh --nj 2 --mfcc-config conf/mfcc_hires.conf \  #注释 GLS 2021.9.7
##    steps/make_mfcc.sh --nj 16 --mfcc-config conf/mfcc_hires.conf \
#    #在p_dev.json和p_test.json,n_dev.json,n_test.json只放1条语音数据时，--nj取1。 2021年 09月 07日 星期二 13:12:04 CST
#    steps/make_mfcc.sh --nj 1 --mfcc-config conf/mfcc_hires.conf \
#      --cmd "$train_cmd" data/${datadir}_hires || exit 1;
#    steps/compute_cmvn_stats.sh data/${datadir}_hires || exit 1;
#    utils/fix_data_dir.sh data/${datadir}_hires || exit 1;
#  done
#fi
#echo "stage11结束。"

#combined_train_set=train_shorter_sp_combined
#if [ $stage -le 13 ]; then
##run_tdnn.sh是run.sh脚本中的最后一步，也是最重要的一步，其训练一个chain模型，与一般的dnn-hmm模型不同，它不需要事先训练一个交叉熵准则的DNN模型，
##而是直接使用对HMM-HMM模型的对齐结果作为输入。训练chain模型需要安装CUDA使用gpu，具体安装步骤上网查吧。
##更换唤醒词，这里需要修改。 GLS 2021.8.12
#  local/chain/run_tdnn.sh --train-set train_shorter --combined-train-set ${combined_train_set}
#fi
#echo "stage13结束。"


###简化版本二

#wav_dir=data/download/mobvoi_hotword_dataset
#for folder in eval; do
#    mkdir -p data/$folder
##    for prefix in p n; do #prefix分别变成p和n，进行for循环。即n_test.json,p_test.json等
#      mkdir -p data/${prefix}_$folder
#      json_path=data/download/mobvoi_hotword_dataset_resources/${prefix}_$folder.json
#      if [ $folder = "eval" ]; then
#        json_path=data/download/mobvoi_hotword_dataset_resources/${prefix}_test.json
#      fi
#      local/prepare_data.py $wav_dir $json_path data/${prefix}_$folder --non-wake-word "FREETEXT" #更换唤醒词，这里需要修改。 GLS 2021.8.12
#    done
#    cat data/p_$folder/wav.scp data/n_$folder/wav.scp > data/$folder/wav.scp
#    cat data/p_$folder/text data/n_$folder/text > data/$folder/text
#    cat data/p_$folder/utt2spk data/n_$folder/utt2spk > data/$folder/utt2spk
#    rm -rf data/p_$folder data/n_$folder

#    dir=data/$folder
#    utils/fix_data_dir.sh $dir
#    steps/make_mfcc.sh --cmd "$train_cmd" --nj 1 $dir  #2改为1  GLS 2021.9.7
#    steps/compute_cmvn_stats.sh $dir
#    utils/fix_data_dir.sh $dir
#    utils/data/get_utt2dur.sh $dir
#    utils/validate_data_dir.sh $dir #validate验证

##    utils/copy_data_dir.sh data/$datadir data/${datadir}_hires
##    steps/make_mfcc.sh --nj 1 --mfcc-config conf/mfcc_hires.conf \
##      --cmd "$train_cmd" data/${datadir}_hires || exit 1;
##    steps/compute_cmvn_stats.sh data/${datadir}_hires || exit 1;
##    utils/fix_data_dir.sh data/${datadir}_hires || exit 1;
#    utils/copy_data_dir.sh data/$folder data/${folder}_hires
#    steps/make_mfcc.sh --nj 1 --mfcc-config conf/mfcc_hires.conf \
#      --cmd "$train_cmd" data/${folder}_hires || exit 1;
#    steps/compute_cmvn_stats.sh data/${folder}_hires || exit 1;
#    utils/fix_data_dir.sh data/${folder}_hires || exit 1;
#done
##结束计时,计时终点 add GLS 2021.9.24
#end_time=`date +%s.%N`
#getTiming  $begin_time $end_time
#exit 1
#combined_train_set=train_shorter_sp_combined
#local/chain/run_tdnn.sh --train-set train_shorter --combined-train-set ${combined_train_set}


#结束计时,计时终点 add GLS 2021.9.24
#end_time=`date +%s.%N`
#getTiming  $begin_time $end_time






##=================================
###简化版本三

#wav_dir=data/download/mobvoi_hotword_dataset
#for folder in eval; do
#    mkdir -p data/$folder
##    for prefix in p n; do #prefix分别变成p和n，进行for循环。即n_test.json,p_test.json等
###    for prefix in p; do #prefix分别变成p和n，进行for循环。即n_test.json,p_test.json等
##      mkdir -p data/${prefix}_$folder
##      json_path=data/download/mobvoi_hotword_dataset_resources/${prefix}_$folder.json
##      if [ $folder = "eval" ]; then
##        json_path=data/download/mobvoi_hotword_dataset_resources/${prefix}_test.json
##      fi
##      local/prepare_data.py $wav_dir $json_path data/${prefix}_$folder --non-wake-word "FREETEXT" #更换唤醒词，这里需要修改。 GLS 2021.8.12
##    done
##    cat data/p_$folder/wav.scp data/n_$folder/wav.scp > data/$folder/wav.scp
##    cat data/p_$folder/text data/n_$folder/text > data/$folder/text
##    cat data/p_$folder/utt2spk data/n_$folder/utt2spk > data/$folder/utt2spk
##    rm -rf data/p_$folder data/n_$folder

#    mkdir -p data/p_$folder
#    json_path=data/download/mobvoi_hotword_dataset_resources/p_test.json

#    local/prepare_data.py $wav_dir $json_path data/p_$folder --non-wake-word "FREETEXT" #更换唤醒词，这里需要修改。 GLS 2021.8.12

#    cat data/p_$folder/wav.scp > data/$folder/wav.scp
#    cat data/p_$folder/text > data/$folder/text
#    cat data/p_$folder/utt2spk > data/$folder/utt2spk
#    rm -rf data/p_$folder data/n_$folder
#    #~44ms

#    dir=data/$folder
#    utils/fix_data_dir.sh $dir
#    #~99ms
#    steps/make_mfcc.sh --cmd "$train_cmd" --nj 1 $dir  #2改为1  GLS 2021.9.7
#    #~214ms
#    steps/compute_cmvn_stats.sh $dir
#    #~260ms
#    utils/fix_data_dir.sh $dir
#    #~320ms
#    utils/data/get_utt2dur.sh $dir
#    #~340ms
#    utils/validate_data_dir.sh $dir #validate验证
##    ~380ms


#    utils/copy_data_dir.sh data/$folder data/${folder}_hires
#    #~480ms
#    steps/make_mfcc.sh --nj 1 --mfcc-config conf/mfcc_hires.conf \
#      --cmd "$train_cmd" data/${folder}_hires || exit 1;
#    #~580ms
#    steps/compute_cmvn_stats.sh data/${folder}_hires || exit 1; #这里生成log。生成log需要花时间，试一试不生成log。 GLS 2021.9.26
#    #~600ms
#    utils/fix_data_dir.sh data/${folder}_hires || exit 1; #这里不用生成的eval_hires内容一样。
#    #~700ms


#done

#combined_train_set=train_shorter_sp_combined
#local/chain/run_tdnn.sh --train-set train_shorter --combined-train-set ${combined_train_set}
##结束计时,计时终点 add GLS 2021.9.24
#end_time=`date +%s.%N`
#getTiming  $begin_time $end_time
#exit 1


###################=================================
##############简化版本四
#rm -rf ./data/eval_hires #add 先删除上次运行产生的对语音与处理的eval_hires文件 GLS 2021.9.27
#rm -rf ./exp/chain/tdnn_1a_online/decode_eval_HiXiaowen_cost0.0 #add 先删除上次decode_eval_HiXiaowen_cost0.0文件 GLS 2021.9.29

#wav_name=$1 #wav_name通过run.sh传的参数获取
#wav_dir=data/download/mobvoi_hotword_dataset
#folder=eval_hires #add 不生成eval来过渡，直接生成eval_hires。减少程序运行的时间。 GLS 2021.9.26
#mkdir -p data/$folder

#mkdir -p data/p_$folder
##json_path=data/download/mobvoi_hotword_dataset_resources/p_test.json
##local/prepare_data.py $wav_dir $json_path data/p_$folder --non-wake-word "FREETEXT" #更换唤醒词，这里需要修改。 GLS 2021.8.12

#local/prepare_data2.py $wav_dir $wav_name data/p_$folder --non-wake-word "FREETEXT" #更换唤醒词，这里需要修改。 GLS 2021.8.12
##~60ms

#cat data/p_$folder/wav.scp > data/$folder/wav.scp
#cat data/p_$folder/text > data/$folder/text
#cat data/p_$folder/utt2spk > data/$folder/utt2spk
#rm -rf data/p_$folder data/n_$folder

#dir=data/$folder
#utils/fix_data_dir.sh $dir
##~120ms

#steps/make_mfcc.sh --nj 1 --mfcc-config conf/mfcc_hires.conf \
#  --cmd "$train_cmd" data/$folder || exit 1;

##~250ms
#steps/compute_cmvn_stats.sh data/$folder || exit 1; #这里生成log。生成log需要花时间，试一试不生成log。 GLS 2021.9.26
##~280ms

#combined_train_set=train_shorter_sp_combined
#local/chain/run_tdnn.sh --train-set train_shorter --combined-train-set ${combined_train_set}

##~800ms
################################################
#结束计时,计时终点 add GLS 2021.9.24
end_time=`date +%s.%N`
getTiming  $begin_time $end_time
exit 1

exit 0


