# you can change cmd.sh depending on what type of queue you are using.
# If you have no queueing system and want to run on a local machine, you
# can change all instances 'queue.pl' to run.pl (but be careful and run
# commands one by one: most recipes will exhaust the memory on your
# machine).  queue.pl works with GridEngine (qsub).  slurm.pl works
# with slurm.  Different queues are configured differently, with different
# queue names and different ways of specifying things like memory;
# to account for these differences you can create and edit the file
# conf/queue.conf to match your queue's configuration.  Search for
# conf/queue.conf in http://kaldi-asr.org/doc/queue.html for more information,
# or search for the string 'default_config' in utils/queue.pl or utils/slurm.pl.
#您可以根据所使用的队列类型更改cmd.sh。
#如果没有排队系统，希望在本地机器上运行，可以将所有实例'queue.pl'更改为run.pl(但是要小心，要逐个运行命令:大多数菜谱会耗尽机器上的内存)。
#pl与GridEngine (qsub)一起工作。slurm.pl与slurm一起工作。
#不同的队列配置不同，有不同的队列名称和不同的指定方式，比如内存;为了考虑到这些差异，您可以创建并编辑conf/queue.conf文件，以匹配您的队列配置。
#在http://kaldi-asr.org/doc/queue.html中搜索conf/queue.conf以获得更多信息，或者在utils/queue.pl或utils/slurm.pl中搜索字符串'default_config'。

#export train_cmd="queue.pl"
#export decode_cmd="queue.pl --mem 4G"
## the use of cuda_cmd is deprecated, used only in 'nnet1',
#export cuda_cmd="queue.pl --gpu 1"

#if [[ "$(hostname -f)" == "*.fit.vutbr.cz" ]]; then
#  queue_conf=$HOME/queue_conf/default.conf # see example /homes/kazi/iveselyk/queue_conf/default.conf,
#  export train_cmd="queue.pl --config $queue_conf --mem 2G --matylda 0.2"
#  export decode_cmd="queue.pl --config $queue_conf --mem 3G --matylda 0.1"
#  export cuda_cmd="queue.pl --config $queue_conf --gpu 1 --mem 10G --tmp 40G"
#fi

#注释 GLS2021年 07月 23日 星期五 11:46:57 CST
export train_cmd="run.pl"
export decode_cmd="run.pl"
# the use of cuda_cmd is deprecated, used only in 'nnet1',
export cuda_cmd="run.pl --gpu 1"

if [[ "$(hostname -f)" == "*.fit.vutbr.cz" ]]; then
  queue_conf=$HOME/queue_conf/default.conf # see example /homes/kazi/iveselyk/queue_conf/default.conf,
  export train_cmd="run.pl --config $queue_conf --mem 2G --matylda 0.2"
  export decode_cmd="run.pl --config $queue_conf --mem 3G --matylda 0.1"
  export cuda_cmd="run.pl --config $queue_conf --gpu 1 --mem 10G --tmp 40G"
fi

