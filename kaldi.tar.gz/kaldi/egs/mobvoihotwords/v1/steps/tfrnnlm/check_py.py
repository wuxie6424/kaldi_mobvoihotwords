import numpy as np
import tensorflow as tf
